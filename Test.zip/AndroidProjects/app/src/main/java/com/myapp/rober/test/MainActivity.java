package com.myapp.rober.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView Hola;
        Hola = findViewById(R.id.Hola);
        Hola.setText(Hola_());


    }

    public String Hola_(){
        String c = "Hola mundo desde otra clase";
        return c;
    }
    }

